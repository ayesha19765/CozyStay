
var w = window.innerWidth;
var h = window.innerHeight;

var x = document.getElementById("w");
x.innerHTML = "Browser width: " + w + ", height: " + h + ".";
